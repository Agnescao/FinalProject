package model;

public class order {

	private int quantity;

	private Product product;

	public order(Product product) {

		this.product = product;
		quantity = 1;

	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public void increaseQuantity() {
		 quantity++;
	}

	public void decreaseQuantity() {
		 quantity--;
	}
	public double getTotal(){
		
		double totalPrice=(this.getQuantity()*product.getPrice());
		return totalPrice;
	}

}
