package model;

import java.util.ArrayList;
import java.util.List;

public class Cart {
	int id;
	String name;
	List<order> items = new ArrayList<order>();     
    
    int numberOfItems;// how many each items are
    double total;// total number of items in the cart
	public Cart() {
		
		numberOfItems =0;
		total = 0;
	}
	
	public Cart(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
    
	public Cart(String name) {
		super();
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void  addoder(Product product){
		order order=new order(product);
		items.add(order);
		order.increaseQuantity();
	}
	
	public List<order> listOrder()
	{
		return items;
	}
	
	public void deleteOrder(Product product)
	{
		items.remove(product);
		
	}
	public void clear(){
		items.clear();
		numberOfItems =0;
		total = 0;
	}

	public void setContents(List<order> items2) {
		// TODO Auto-generated method stub
		
	}

   
   

	

	


	
    
    
    
    // -------------------------------------------------------
    //  Adds an order to the shopping cart.
    // -------------------------------------------------------
    /*public void addToCart(String productName, int quantity,int price )
    { 

        order temp = new order(productName, quantity, price);
        totalPrice += (price * quantity);
        orderCount += quantity;
        cart[orderCount] = temp;
        if(orderCount==capacity)
        {
            increaseSize();
        }
    }

	private void increaseSize() {
		// TODO Auto-generated method stub
		order[] temp = new order[capacity+3];
        for(int i=0; i < capacity; i++)
        {
            temp[i] = cart[i];
        }
        cart = temp; 
        temp = null;
        capacity = cart.length;
    }
	*/
}
