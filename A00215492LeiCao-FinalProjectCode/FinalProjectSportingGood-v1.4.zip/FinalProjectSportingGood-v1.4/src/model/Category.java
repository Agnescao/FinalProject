/**
 * 
 */
package model;

/**
 * @author Caolei
 *
 */
public class Category {
	private int id;
	private String Cname;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	

}
