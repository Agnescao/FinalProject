function checkIfNull()
{
var x=document.getElementById("n").value;
var y=document.getElementById("pwd").value;
if(x=="" || y=="")
	{
	alert("Please enter your user name and your password");
	}
}
