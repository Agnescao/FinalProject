function setId(id){
	console.log(id);
	var modalID;
	sessionScope.put("modalID", id);
	out.println(id);
	
	
}